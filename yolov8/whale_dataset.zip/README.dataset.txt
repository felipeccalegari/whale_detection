# Baleias 2 > 2025-06-28 7:15pm
https://universe.roboflow.com/baleias/baleias-2

Provided by a Roboflow user
License: CC BY 4.0

